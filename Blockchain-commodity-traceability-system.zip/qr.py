import qrcode
from PIL import Image
from myJson import *


def getQR(filename):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    # 这个地方为字符串
    # qr.add_data(str({'123': 12, 'miao': '中毒阿哥'}))
    qr.add_data(str(myRead(filename)))
    qr.make(fit=True)
    img = qr.make_image()
    img.save('static/erWeiMa/'+filename+'.png')


# getQR('1587163')



# qr = qrcode.QRCode(
#     version=1,
#     error_correction=qrcode.constants.ERROR_CORRECT_L,
#     box_size=10,
#     border=4,
# )
# #这个地方为字符串
# qr.add_data(str({'123':12,'miao':'中毒阿哥'}))
# qr.make(fit=True)
# img = qr.make_image()
# img.save('123.png')
