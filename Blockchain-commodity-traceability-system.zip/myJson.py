import json

def myWrite(data1,filename='test'):

    # data=myRead()
    file = open('./data/'+filename+'.json', 'w', encoding='utf-8')
    json.dump(data1, file, ensure_ascii=False)
    file.close()





def myRead(filename='test'):
    with open('./data/'+filename+'.json', 'r', encoding='utf-8') as file:
        json_str = None
        try:
            json_str = json.load(file)
        except json.decoder.JSONDecodeError:
            return None
            # print("未创建此文件")
        json_list = eval(json_str)

        for json_dict in json_list:
            #获取公共数据
            hash = json_dict['hash']
            previous_hash = json_dict['previous_hash']
            time_stamp = json_dict['time_stamp']
            nonce = json_dict['nonce']

            # 区分获取msg内容
            msg_str = json_dict['msg']
            id_index = msg_str.find('id')
            startTime_index = msg_str.find('startTime')

            if id_index != -1:
                #获取第一个列表内容
                name_index = msg_str.find('name')
                birthPlace_index = msg_str.find('birthPlace')
                birthTime_index = msg_str.find('birthTime')
                id = msg_str[id_index + 6:name_index - 4]
                name = msg_str[name_index + 8:birthPlace_index - 4]
                birthPlace = msg_str[birthPlace_index + 14:birthTime_index - 4]
                birthTime = msg_str[birthTime_index + 13:-2]

                dict_one = {
                    'hash': hash,
                    'previous_hash': previous_hash,
                    'time_stamp': time_stamp,
                    'nonce': nonce,
                    'id': id,
                    'name': name,
                    'birthPlace': birthPlace,
                    'birthTime': birthTime
                }
            elif startTime_index != -1:
                #操作第二个列表内容
                danHao_index = msg_str.find('danHao')
                startTime = msg_str[startTime_index + 13:danHao_index - 4]
                danHao = msg_str[danHao_index + 10:-2]

                dict_two = {
                    'hash': hash,
                    'previous_hash': previous_hash,
                    'time_stamp': time_stamp,
                    'nonce': nonce,
                    'startTime': startTime,
                    'danHao': danHao
                }
            else:
                #操作第三个列表
                arrive_index = msg_str.find('arrive')
                person_index = msg_str.find('person')
                arrive = msg_str[arrive_index + 10:person_index -4]
                person = msg_str[person_index + 10: -2]

                dict_three = {
                    'hash': hash,
                    'previous_hash': previous_hash,
                    'time_stamp': time_stamp,
                    'nonce': nonce,
                    'arrive': arrive,
                    'person': person
                }
        lastList=[dict_one,dict_two,dict_three]
        return  lastList
        # print(dict_one)
        # print(type(dict_one))
        # print(dict_two)
        # print(dict_three)





# myRead('1587163')




#
# def myRead(filename='test'):
#     file = open('./data/'+filename+'.json', 'r', encoding='utf-8')
#     s=None
#     try:
#         s = json.load(file)
#     except json.decoder.JSONDecodeError:
#         print("未创建此文件")
#     li=eval(s)
#     print(li)
#     print(type(li))
#     print(len(li))
#     print(li[0])




# myRead('15872')

# myWrite({'sex':'nan'})
# # print(str(myRead()))

