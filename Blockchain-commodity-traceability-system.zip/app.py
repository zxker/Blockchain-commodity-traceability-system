from flask import Flask,render_template,Response,Request,request,redirect,url_for
import re
from dataBase import Connect
from mine import *
# from dataBase import Connect  # 调用数据库模块
app = Flask(__name__)
root=''
yongHu=''
Delete=None
# conn=Connect()
# res = conn.execute('select * from users limit 13,1')
# print(res.fetchone())
# print("我调用了")
block={}
@app.route('/',methods=['GET','POST'])
def hello_world():
    global root
    global yongHu
    if request.method=='GET':
        return render_template('login.html')
    elif request.method=='POST':
        phone=request.form.get("phone")
        psd=request.form.get("psd")
        conn=Connect()
        sql=" select* from users where inputEmail='%s' and psd='%s';"% (phone,psd)
        res=conn.execute(sql)
        last=res.fetchone()
        if last==None:

            return render_template('login.html',cuo=True)
        else:
            root = phone[0]
            yongHu=last[1]
            return render_template('first.html',use=yongHu)



        # redirect('index.html')
        # return render_template('index.html')

from myJson import *
@app.route('/edit/',methods=['GET','POST'])
def myedit():
    global block
    if request.method=='GET':
        print("身份是：")
        print(type(root))
        print(root)
        return render_template('edit.html',shefen=root,user=yongHu,temp=('','生产者','运输者','仓库管理员'))
    elif request.method == 'POST':
        id = request.form.get("id")
        name = request.form.get("name")
        birthPlace = request.form.get("birthPlace")
        birthTime = request.form.get("birthTime")
        startTime = request.form.get("startTime")
        danHao = request.form.get("danHao")
        arrive = request.form.get("arrive")
        person = request.form.get("person")
        coon = Connect()
        if root=='1':#生产商
            sql="insert into product(id,name,birthPlace,birthTime) values('%d','%s','%s','%s');" % (int(id),name,birthPlace,birthTime)
            coon.execute(sql)
            #添加商品信息的时候自动加入区块链
            block[id]=EduChain(5)
            c=block[id]
            c.add_block(Block(str({'id':id,'name':name,'birthPlace':birthPlace,'birthTime':birthTime}),'0'))
            c.show()
            c.isChainValid()
            myWrite(c.saveShow(), id)
            return "添加成功"
        elif root == '2':  # 运输商
            sql ="update product set startTime='%s',danHao='%s' where id='%d';" %(startTime,danHao,int(id))
            coon.execute(sql)
            c = block[id]
            c.add_block(Block(str({'startTime': startTime, 'danHao': danHao}), c.list[len(c.list) - 1].hash))
            c.show()
            c.isChainValid()
            myWrite(c.saveShow(), id)
            return "添加成功"
            # sql = "insert into product(id,) values('%d','%s','%s','%s');" % (
            # int(id), name, birthPlace, birthTime)
            # coon.execute(sql)
            # return "添加成功"
        elif root=='3':#仓库管理员
            sql="update product set arrive='%s',person='%s' where id='%d';" %(arrive,person,int(id))
            coon.execute(sql)
            c = block[id]
            c.add_block(Block(str({'arrive': arrive, 'person': person}), c.list[len(c.list) - 1].hash))
            c.show()
            c.isChainValid()
            myWrite(c.saveShow(),id)

            return "添加成功"
        else:
            return render_template('edit.html', shefen=root)


#以json文件保存结果















@app.route('/register/',methods=['GET','POST'])#注册
def myRegister():
    if request.method=='GET':
        return render_template('register.html')
    elif request.method == 'POST':
        inputEmail=request.form.get("inputEmail")
        username=request.form.get("username")
        psd=request.form.get("psd")
        re_psd=request.form.get("re_psd")
        print("hello")
        # return "注册了"
        # print("哈哈")
        # temp='insert into users(inputEmail,username,psd) values('+str(inputEmail)+','+str(username)+','+str(psd)+');'
        sql=( "insert into users(inputEmail,username,psd) values('%s','%s','%s');" % (inputEmail,username,psd))
        conn=Connect()
        conn.execute(sql)
        return redirect(url_for('hello_world'))
        # print(temp)
        # print("我调用了")
        # #print(inputEmail,username,psd,re_psd)#调用数据库



@app.route('/index/')
def myIndex():
    return  render_template('index.html')

@app.route('/about/')
def my_about():
    return render_template('about.html')


@app.route('/first/')
def myFirst():
    return render_template('first.html')



@app.route('/company/',methods=['GET','POST'])
def company():
    global Delete
    if request.method=='GET':
        return render_template('./html/company_manage.html')
    elif request.method=='POST':
        id = request.form.get("id")
        name = request.form.get("name")
        conn=Connect()
        sql=''
        if id!='':
            sql="SELECT * FROM product where id=%d"% int(id)
            temp=conn.execute(sql)
            u = temp.fetchall()
            Delete=u
            conn.close()
            if len(u)==0:
                return render_template('./html/company_manage.html', temp='error')
            return render_template('./html/company_manage.html', u=u)
        elif name!='':
            sql = "SELECT * FROM product where name='%s'" % name
            temp = conn.execute(sql)
            u = temp.fetchall()
            print(type(u))
            print(u)
            Delete=u;
            conn.close()
            if  len(u)==0:
                return render_template('./html/company_manage.html', temp='error')
            return render_template('./html/company_manage.html', u=u)
        else:
            return render_template('./html/company_manage.html', temp='error')




from myJson import *
from qr import *
#区块链的查询
@app.route('/quiryBlock/',methods=['GET','POST'])

def quiryBlock():
    if request.method=='GET':
        return render_template('quiryBlock.html',u=None)
    elif request.method=='POST':
        id = request.form.get("id")
        if id!='':
            getQR(id)
            print("get到了")
            mylist=myRead(id)

            # if len(u)==0:
            #     return render_template('quiryBlock.html', temp='error')
            return render_template('quiryBlock.html', u=mylist)
        else:
            return render_template('quiryBlock.html', u=None)

        # elif name!='':
        #     sql = "SELECT * FROM product where name='%s'" % name
        #     temp = conn.execute(sql)
        #     u = temp.fetchall()
        #     conn.close()
        #     if  len(u)==0:
        #         return render_template('./html/company_manage.html', temp='error')
        #     return render_template('./html/company_manage.html', u=u)
        # else:
        #     return render_template('./html/company_manage.html', temp='error')




# //background process happening without any refreshing
@app.route('/background_process_test')
def background_process_test():
    # print("Hello")
    if Delete!=None:
        for i in Delete:
            conn=Connect()
            sql="DELETE FROM product WHERE id=%d" % int(i[0])
            conn.execute(sql)
            conn.close()
            print("删除成功")
    else:
        print("没有删除")

    return "nothing"


if __name__ == '__main__':
    app.run(debug=True)
