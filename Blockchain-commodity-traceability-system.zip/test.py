from mine import Block,EduChain

print('EduChain CLT Apr 2018 by fxt0706')
# c = EduChain(5)
# c.add_block(Block(str({'age':16,'name':'中毒阿哥'}),'0'))
# print(c.have)
# c.add_block(Block(str({'age':19,'name':'关啸'}),c.list[len(c.list)-1].hash))
# c.show()
# c.isChainValid()


block={}
print(block.get("12"))
block['158']=EduChain(4)
print(block.get('158'))
block['134']=EduChain(4)
block['158'].add_block(Block("'age':16,'name':'中毒阿哥'",'0'))

block['158'].add_block(Block(str({'age':19,'name':'关啸'}),block['158'].list[len(block['158'].list)-1].hash))
block['158'].show()

c=block['134']
c.add_block(Block(str({'age':99,'name':'小猫'}),'0'))
print(c.have)
c.add_block(Block(str({'age':109,'name':'Alice'}),c.list[len(c.list)-1].hash))
block['134'].show()
# c.isChainValid()
# block['134'].add_block(Block(str({'age':29,'name':'134'}),'0'))
#
# block['134'].add_block(Block(str({'age':19,'name':'关啸'}),block['134'].list[len(block['134'].list)-1].hash))
# block['134'].show()

#
# def test(*my):
#     print(type(my))
#     print(my[0],my[1])
#
#
# test('hahh',3)
#

# def add(c,temp):
#     c.
