from sqlalchemy import create_engine
# from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, UniqueConstraint, Index
# from sqlalchemy.orm import sessionmaker
#
# HOSTNAME='127.0.0.1'#本地mysql  改成别的就连网络上的mysql
# PORT='3306'
# DATABASE='BiShe'
# USERNAME='root'
# PASSWORD='123456'
# DB_URI="mysql+pymysql://{username}:{password}@{host}:{port}/{db}?charset=utf8".format(username=USERNAME,
#                                                                                       password=PASSWORD,
#                                                                                       host=HOSTNAME,
#                                                                                       port=PORT,
#                                                                                       db=DATABASE)
#
#
# # Base = declarative_base()
# #
# #
# # # 一类对应一表
# # class Users(Base):
# #     __tablename__ = 'users'  # 数据库表名称
# #     phone = Column(Integer, primary_key=True)  # id 主键
# #     username = Column(String(32), index=True, nullable=False)  # name列，索引，不可为空
# #     psd=Column(String(32),nullable=False)
# #     # email = Column(String(32), unique=True) # unique是否唯一
# #     # 注意！！！datetime.datetime.now 不能加括号，加了括号，以后永远是当前时间
# #     # ctime = Column(DateTime, default=datetime.datetime.now)
# #     # extra = Column(Text, nullable=True)
# #
# #     __table_args__ = (
# #         # UniqueConstraint('id', 'name', name='uix_id_name'), # 联合唯一
# #         # Index('ix_id_name', 'name', 'email'), # 索引
# #     )
#
#
#
#
# # session =sessionmaker(engine)()
# #     # 创建继承base的所有表
# # Base.metadata.create_all(engine)
#
# # def init_db():
# #     """
# #     根据类创建数据库表
# #     :return:
# #     """
# #     engine =create_engine(DB_URI)
# #     session =sessionmaker(engine)()
# #     # 创建继承base的所有表
# #     Base.metadata.create_all(engine)
# #
# # if __name__ == '__main__':
# #     # drop_db()
# #     init_db()
#
#
#
#
HOSTNAME = '127.0.0.1'  # 本地mysql  改成别的就连网络上的mysql
PORT = '3306'
DATABASE = 'BiShe'
USERNAME = 'root'
PASSWORD = '123456'
DB_URI = "mysql+pymysql://{username}:{password}@{host}:{port}/{db}?charset=utf8".format(username=USERNAME,
                                                                                        password=PASSWORD,
                                                                                        host=HOSTNAME,
                                                                                        port=PORT,
                                                                                        db=DATABASE)

engine = create_engine(DB_URI)
def Connect():

    # 判断连接成功
    conn = engine.connect()
    return conn


#



